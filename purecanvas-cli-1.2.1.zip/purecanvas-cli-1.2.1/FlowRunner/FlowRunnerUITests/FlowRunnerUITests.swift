/*
input: 环境变量 PURECANVAS_FLOW_FILE（流程 JSON 路径）、PURECANVAS_MODE（replay|describe|session）、PURECANVAS_BUNDLE_ID（覆盖 flow.app）、PURECANVAS_SESSION_DIR（session 模式文件通道目录）。
output: replay 回放流程落截图附件；describe 落层级文本附件；session 长驻文件通道（cmd-*.json → resp-*.json，空闲 30 分钟自退），交互执行 launch/tap/drag/back/replay_steps/type/await/shot/describe。
pos: purecanvas capture 的执行体（独立子工程，由 CLI build-for-testing 后 test-without-building 驱动）；流程校验在 CLI 侧 FlowSpec 完成，runner 只做宽松解析；一旦我被更新，务必更新我的开头注释。
*/
import XCTest

final class FlowRunnerUITests: XCTestCase {
    private enum Mode: String { case replay, describe, session }

    private struct Flow {
        var bundleID: String
        var steps: [[String: Any]]
    }

    private var flow: Flow?

    override func setUpWithError() throws {
        continueAfterFailure = false
        let mode = Mode(rawValue: ProcessInfo.processInfo.environment["PURECANVAS_MODE"] ?? "replay") ?? .replay
        if mode == .session {
            // 会话模式无流程文件：bundle id 由 launch 命令提供
            flow = nil
            return
        }
        let env = ProcessInfo.processInfo.environment
        let flowPath = env["PURECANVAS_FLOW_FILE"] ?? ""

        guard !flowPath.isEmpty else {
            throw runnerError(0, "缺少 PURECANVAS_FLOW_FILE（CLI 应以 TEST_RUNNER_ 前缀透传并先经 FlowSpec 校验）")
        }
        guard let data = FileManager.default.contents(atPath: flowPath),
              let root = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw runnerError(0, "流程文件不可读或非 JSON 对象：\(flowPath)")
        }
        let bundleID = env["PURECANVAS_BUNDLE_ID"] ?? (root["app"] as? String ?? "")
        guard !bundleID.isEmpty else {
            throw runnerError(0, "流程缺少 app（bundle id），也未提供 PURECANVAS_BUNDLE_ID 覆盖")
        }
        let steps = root["steps"] as? [[String: Any]] ?? []
        flow = Flow(bundleID: bundleID, steps: steps)
    }

    func testFlow() throws {
        let mode = Mode(rawValue: ProcessInfo.processInfo.environment["PURECANVAS_MODE"] ?? "replay") ?? .replay

        switch mode {
        case .session:
            try runSession()
        case .describe:
            guard let flow else { return }
            try runDescribe(XCUIApplication(bundleIdentifier: flow.bundleID))
        case .replay:
            guard let flow else { return }
            try runReplay(XCUIApplication(bundleIdentifier: flow.bundleID), flow)
        }
    }

    // MARK: - session 模式：文件通道长驻（cmd-*.json → resp-*.json）

    private struct SessionCommand {
        let id: String
        let action: String
        let params: [String: Any]
        let fileURL: URL
    }

    /// 空闲自退：无命令超过该时长写 end 退出（宿主包装脚本随后自动 simctl shutdown 释放无头模拟器）
    private static let sessionIdleTimeout: TimeInterval = 10 * 60
    private static let sessionPollInterval: TimeInterval = 0.15

    private func runSession() throws {
        // 会话默认 executionTimeAllowance 10 分钟（启用 test timeouts 时）会杀进程——显式放宽
        executionTimeAllowance = 28 * 3600
        let env = ProcessInfo.processInfo.environment
        let channelPath = env["PURECANVAS_SESSION_DIR"] ?? ""
        guard !channelPath.isEmpty else {
            throw runnerError(0, "session 模式缺少 PURECANVAS_SESSION_DIR（宿主文件通道目录）")
        }
        let channel = URL(fileURLWithPath: channelPath, isDirectory: true)
        try FileManager.default.createDirectory(at: channel, withIntermediateDirectories: true)
        try Data("ready \(Date().timeIntervalSince1970)".utf8).write(to: channel.appendingPathComponent("ready"))

        var application: XCUIApplication?
        var lastActivity = Date()

        while true {
            let commands = pollSessionCommands(channel: channel)
            for command in commands {
                lastActivity = Date()
                let reply = executeSessionCommand(command, application: &application)
                try? JSONSerialization.data(withJSONObject: reply)
                    .write(to: channel.appendingPathComponent("resp-\(command.id).json"))
                try? FileManager.default.removeItem(at: command.fileURL)
                if command.action == "stop" {
                    if let app = application, app.state != .notRunning {
                        app.terminate()
                    }
                    try? Data("stop \(Date().timeIntervalSince1970)".utf8)
                        .write(to: channel.appendingPathComponent("end"))
                    return
                }
            }
            if Date().timeIntervalSince(lastActivity) > Self.sessionIdleTimeout {
                if let app = application, app.state != .notRunning {
                    app.terminate()
                }
                try? Data("idle \(Date().timeIntervalSince1970)".utf8)
                    .write(to: channel.appendingPathComponent("end"))
                return
            }
            Thread.sleep(forTimeInterval: Self.sessionPollInterval)
        }
    }

    private func pollSessionCommands(channel: URL) -> [SessionCommand] {
        let files = (try? FileManager.default.contentsOfDirectory(at: channel, includingPropertiesForKeys: nil)) ?? []
        return files
            .filter { $0.lastPathComponent.hasPrefix("cmd-") && $0.pathExtension == "json" }
            .sorted { $0.lastPathComponent < $1.lastPathComponent }
            .compactMap { url in
                guard let data = FileManager.default.contents(atPath: url.path),
                      let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                      let id = obj["id"] as? String,
                      let action = obj["action"] as? String else { return nil }
                return SessionCommand(id: id, action: action, params: obj["params"] as? [String: Any] ?? [:], fileURL: url)
            }
    }

    /// 会话命令执行：tap/drag/back/type/await/wait/swipe/terminate 复用 executeStep；launch/replay_steps/describe/shot/ping/stop 会话专属
    private func executeSessionCommand(_ command: SessionCommand, application: inout XCUIApplication?) -> [String: Any] {
        func reply(_ ok: Bool, _ data: [String: Any], _ error: String?) -> [String: Any] {
            var payload: [String: Any] = ["id": command.id, "ok": ok]
            data.forEach { payload[$0.key] = $0.value }
            if let error { payload["error"] = error }
            return payload
        }

        let wantsShot = command.params["returnShot"] as? Bool == true
        let settleSeconds = max(0.05, (command.params["settleMs"] as? Double ?? 360) / 1000.0)

        switch command.action {
        case "ping":
            return reply(true, ["uptime": Date().timeIntervalSince1970], nil)

        case "launch":
            let bundleID = command.params["bundleId"] as? String ?? ""
            guard !bundleID.isEmpty else { return reply(false, [:], "launch 需要 bundleId") }
            let app = application ?? XCUIApplication(bundleIdentifier: bundleID)
            application = app
            let forceRelaunch = command.params["relaunch"] as? Bool == true
            if app.state == .runningForeground, !forceRelaunch {
                var out: [String: Any] = ["bundleId": bundleID, "attached": true]
                if wantsShot {
                    let png = activeScreenScreenshot(app: app).pngRepresentation
                    out["pngBase64"] = png.base64EncodedString()
                }
                return reply(true, out, nil)
            }
            do {
                if forceRelaunch, app.state != .notRunning {
                    app.terminate()
                    Thread.sleep(forTimeInterval: 0.4)
                }
                try executeStep(["launch": command.params], index: 0, app: app)
                var out: [String: Any] = ["bundleId": bundleID, "attached": false]
                if wantsShot {
                    Thread.sleep(forTimeInterval: settleSeconds)
                    let png = activeScreenScreenshot(app: app).pngRepresentation
                    out["pngBase64"] = png.base64EncodedString()
                }
                return reply(true, out, nil)
            } catch {
                return reply(false, [:], error.localizedDescription)
            }

        case "describe":
            guard let app = application, app.state == .runningForeground else {
                return reply(false, [:], "App 未运行——先执行 launch")
            }
            return reply(true, ["hierarchy": app.debugDescription], nil)

        case "shot":
            guard let app = application else { return reply(false, [:], "App 未运行——先执行 launch") }
            dismissSystemPromptsIfNeeded(app: app)
            let png = activeScreenScreenshot(app: app).pngRepresentation
            return reply(true, ["pngBase64": png.base64EncodedString()], nil)

        case "tap", "drag", "back", "type", "await", "wait", "swipe", "terminate":
            guard let app = application, app.state == .runningForeground else {
                return reply(false, [:], "App 未运行——先执行 launch")
            }
            do {
                try executeStep([command.action: command.params], index: 0, app: app)
                var out: [String: Any] = [:]
                if wantsShot {
                    Thread.sleep(forTimeInterval: settleSeconds)
                    let png = activeScreenScreenshot(app: app).pngRepresentation
                    out["pngBase64"] = png.base64EncodedString()
                }
                return reply(true, out, nil)
            } catch {
                return reply(false, [:], error.localizedDescription)
            }

        case "replay_steps":
            let bundleID = command.params["bundleId"] as? String ?? ""
            let app: XCUIApplication
            if !bundleID.isEmpty {
                let resolved = application ?? XCUIApplication(bundleIdentifier: bundleID)
                application = resolved
                app = resolved
            } else if let existing = application {
                app = existing
            } else {
                return reply(false, [:], "replay_steps 需要 bundleId 或已启动的 App")
            }
            do {
                if command.params["relaunch"] as? Bool == true {
                    if app.state != .notRunning {
                        app.terminate()
                        Thread.sleep(forTimeInterval: 0.35)
                    }
                    try executeStep(["launch": command.params], index: 0, app: app)
                }
                let steps = command.params["steps"] as? [[String: Any]] ?? []
                for (idx, stepObj) in steps.enumerated() {
                    try executeStep(stepObj, index: idx + 1, app: app)
                    Thread.sleep(forTimeInterval: 0.32)
                }
                Thread.sleep(forTimeInterval: settleSeconds)
                let png = activeScreenScreenshot(app: app).pngRepresentation
                return reply(true, ["pngBase64": png.base64EncodedString()], nil)
            } catch {
                return reply(false, [:], error.localizedDescription)
            }

        case "stop":
            return reply(true, [:], nil)

        default:
            return reply(false, [:], "未知会话命令 '\(command.action)'")
        }
    }

    // MARK: - describe 模式：UI 层级文本（identifier/label/frame），AI 据此写流程选择器

    private func runDescribe(_ application: XCUIApplication) throws {
        if application.state != .runningForeground {
            application.launch()
        }
        Thread.sleep(forTimeInterval: 1.0)
        let attachment = XCTAttachment(string: application.debugDescription)
        attachment.name = "describe-hierarchy"
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    // MARK: - replay 模式

    private func runReplay(_ application: XCUIApplication, _ flow: Flow) throws {
        guard !flow.steps.isEmpty else {
            throw runnerError(0, "流程 steps 为空")
        }
        for (index, rawStep) in flow.steps.enumerated() {
            try executeStep(rawStep, index: index, app: application)
        }
    }

    private func executeStep(_ rawStep: [String: Any], index: Int, app: XCUIApplication) throws {
        let step = index + 1
        guard let action = rawStep.keys.first else { return }
        switch action {
        case "echo":
            print("[flow \(step)] \(rawStep[action] ?? "")")

        case "launch":
            let body = rawStep[action] as? [String: Any] ?? [:]
            var args: [String] = ["-demoMode", "-hasCompletedOnboarding", "YES"]
            if let lang = body["language"] as? String, !lang.isEmpty {
                let appLangMode: String = {
                    let lower = lang.lowercased()
                    if lower.hasPrefix("en") { return "en" }
                    if lower.hasPrefix("zh-hant") || lower == "zh-tw" || lower == "zh-hk" { return "zh-Hant" }
                    if lower.hasPrefix("zh") { return "zh-Hans" }
                    if lower.hasPrefix("ja") { return "ja" }
                    if lower.hasPrefix("ko") { return "ko" }
                    return lang
                }()
                args.append(contentsOf: [
                    "-AppleLanguages", "(\(lang))",
                    "-AppleLocale", lang,
                    "-appLanguageMode", appLangMode,
                ])
            }
            if let customArgs = body["args"] as? [String] {
                args.append(contentsOf: customArgs)
            }
            app.launchArguments = args
            if let customEnv = body["env"] as? [String: String] {
                var merged = app.launchEnvironment
                customEnv.forEach { merged[$0.key] = $0.value }
                app.launchEnvironment = merged
            }
            // launch 偶发与 springboard 竞态：状态没起来就 terminate 重拉一次（对齐 goldie 经验）
            app.launch()
            Thread.sleep(forTimeInterval: 1.0)
            if app.state != .runningForeground {
                app.terminate()
                Thread.sleep(forTimeInterval: 1.5)
                app.launch()
                Thread.sleep(forTimeInterval: 1.0)
            }
            if let orient = (body["orientation"] as? String)?.lowercased() {
                switch orient {
                case "portrait": XCUIDevice.shared.orientation = .portrait
                case "portraitupsidedown": XCUIDevice.shared.orientation = .portraitUpsideDown
                case "landscape", "landscapeleft": XCUIDevice.shared.orientation = .landscapeLeft
                case "landscaperight": XCUIDevice.shared.orientation = .landscapeRight
                default: break
                }
                Thread.sleep(forTimeInterval: 0.6)
            }

        case "tap":
            guard let body = rawStep[action] as? [String: Any] else { throw runnerError(step, "tap 缺少参数对象") }
            if let coord = normalizedCoordinate(body) {
                app.coordinate(withNormalizedOffset: CGVector(dx: coord.x, dy: coord.y)).tap()
            } else {
                let isOptional = body["optional"] as? Bool == true
                let defaultTimeout: Double = isOptional ? 1500 : 8000
                let timeout = max(0.2, (body["timeoutMs"] as? Double ?? defaultTimeout) / 1000)
                if let element = try waitForResolvedElement(body, app: app, action: "tap", step: step, timeout: timeout) {
                    smartTap(element, app: app, step: step)
                } else if isOptional {
                    print("[flow \(step)] optional tap 未命中，跳过")
                } else if isKeyboardSubmitLabel(body), !app.keyboards.firstMatch.exists {
                    // iPhone Duo 等设备在连接硬件键盘或软键盘未弹出时，点击键盘“完成/搜索/Return”自动降级为发送回车
                    print("[flow \(step)] 软键盘未弹出，自动改用回车提交 (\\n)")
                    app.typeText("\n")
                } else {
                    throw notFound(body, step: step, action: "tap", app: app)
                }
            }

        case "drag":
            guard let body = rawStep[action] as? [String: Any],
                  let fromX = body["fromX"] as? Double,
                  let fromY = body["fromY"] as? Double,
                  let toX = body["toX"] as? Double,
                  let toY = body["toY"] as? Double else {
                throw runnerError(step, "drag 需要 {fromX, fromY, toX, toY} 归一化坐标")
            }
            let hold = max(0.01, min(1.0, (body["duration"] as? Double) ?? 0.04))
            let start = app.coordinate(withNormalizedOffset: CGVector(dx: max(0.02, min(0.98, fromX)), dy: max(0.02, min(0.98, fromY))))
            let end = app.coordinate(withNormalizedOffset: CGVector(dx: max(0.02, min(0.98, toX)), dy: max(0.02, min(0.98, toY))))
            start.press(forDuration: hold, thenDragTo: end)

        case "back":
            let navBack = app.navigationBars.buttons.element(boundBy: 0)
            if navBack.exists {
                smartTap(navBack, app: app, step: step)
            } else {
                let start = app.coordinate(withNormalizedOffset: CGVector(dx: 0.02, dy: 0.5))
                let end = app.coordinate(withNormalizedOffset: CGVector(dx: 0.82, dy: 0.5))
                start.press(forDuration: 0.04, thenDragTo: end)
            }

        case "type":
            guard let body = rawStep[action] as? [String: Any] else {
                throw runnerError(step, "type 需要 {into: <选择器>?, text: <文本>?, submit: Bool?}")
            }
            let text = body["text"] as? String ?? ""
            let wantsSubmit = body["submit"] as? Bool == true
            var targetElement: XCUIElement?

            if let into = body["into"] as? [String: Any], !into.isEmpty {
                if let coord = normalizedCoordinate(into) {
                    app.coordinate(withNormalizedOffset: CGVector(dx: coord.x, dy: coord.y)).tap()
                    Thread.sleep(forTimeInterval: 0.25)
                } else {
                    let timeout = max(0.5, (into["timeoutMs"] as? Double ?? 8000) / 1000)
                    guard let resolved = try waitForResolvedElement(into, app: app, action: "type", step: step, timeout: timeout) else {
                        if into["optional"] as? Bool == true {
                            print("[flow \(step)] optional type 未命中输入框，跳过")
                            return
                        }
                        throw notFound(into, step: step, action: "type", app: app)
                    }
                    targetElement = resolved
                    smartTap(resolved, app: app, step: step)
                    Thread.sleep(forTimeInterval: 0.25)
                }
            }

            if !text.isEmpty {
                typeTextResiliently(text, into: targetElement, app: app, step: step)
            }
            if wantsSubmit {
                Thread.sleep(forTimeInterval: 0.15)
                if let targetElement, targetElement.exists {
                    targetElement.typeText("\n")
                } else {
                    app.typeText("\n")
                }
                Thread.sleep(forTimeInterval: 0.45)
                dismissSystemPromptsIfNeeded(app: app)
            }

        case "await":
            guard let body = rawStep[action] as? [String: Any] else {
                throw runnerError(step, "await 需要 {visible: <选择器>} 或 {idle: true}")
            }
            if body["idle"] as? Bool == true {
                try awaitIdle(body: body, step: step)
                return
            }
            guard let condition = body["visible"] as? [String: Any] else {
                throw runnerError(step, "await 支持 {visible: <选择器>, timeoutMs: Int?} 或 {idle: true, stableMs: Int?}")
            }
            let isOptional = (body["optional"] as? Bool == true) || (condition["optional"] as? Bool == true)
            let defaultTimeout: Double = isOptional ? 1500 : 8000
            let timeout = max(0.1, (body["timeoutMs"] as? Double ?? condition["timeoutMs"] as? Double ?? defaultTimeout) / 1000)
            if let _ = try waitForResolvedElement(condition, app: app, action: "await", step: step, timeout: timeout) {
                return
            }
            if isOptional {
                print("[flow \(step)] optional await 未命中，跳过")
                return
            }
            throw notFound(condition, step: step, action: "await", app: app)

        case "record":
            // 录屏由 CLI 在会话模式下经 simctl recordVideo 驱动；一次性回放无法逐段控制
            throw runnerError(step, "record 步骤需要会话模式（CLI 检测到 record 会自动切换；若手动跑 xcodebuild 请去掉 record 步骤）")

        case "wait":
            let ms = rawStep[action] as? Double ?? 0
            Thread.sleep(forTimeInterval: max(0, ms) / 1000)

        case "swipe":
            guard let body = rawStep[action] as? [String: Any],
                  let direction = body["direction"] as? String else {
                throw runnerError(step, "swipe 需要 {direction: up|down|left|right}")
            }
            switch direction {
            case "up": app.swipeUp()
            case "down": app.swipeDown()
            case "left": app.swipeLeft()
            case "right": app.swipeRight()
            default: throw runnerError(step, "未知 swipe 方向 '\(direction)'")
            }

        case "shot":
            guard let body = rawStep[action] as? [String: Any],
                  let name = body["name"] as? String, !name.isEmpty else {
                throw runnerError(step, "shot 需要 {name: <文件名，不含扩展>}")
            }
            dismissSystemPromptsIfNeeded(app: app)
            // 黑屏防护：截图前确认画面非全黑（撞启动动画时自动等待）
            try awaitNonBlackScreen(step: step, app: app)
            let attachment = XCTAttachment(screenshot: activeScreenScreenshot(app: app))
            attachment.name = name
            attachment.lifetime = .keepAlways
            add(attachment)

        case "terminate":
            app.terminate()

        default:
            throw runnerError(step, "未知 action '\(action)'（FlowSpec 校验应已在 CLI 侧拦截）")
        }
    }

    // MARK: - 多屏感知截图（iPhone Duo 折叠态 466×678pt vs 展开态 669×951pt 自动选活动屏幕）

    private func activeScreenScreenshot(app: XCUIApplication? = nil) -> XCUIScreenshot {
        let screens = XCUIScreen.screens
        if screens.count > 1 {
            if let app, app.exists {
                let frame = app.frame
                let maxDim = max(frame.width, frame.height)
                if maxDim > 750, let innerScreen = screens.last {
                    let shot = innerScreen.screenshot()
                    if shot.pngRepresentation.count > 5000 { return shot }
                } else if maxDim > 0, maxDim <= 750 {
                    let shot = XCUIScreen.main.screenshot()
                    if shot.pngRepresentation.count > 5000 { return shot }
                }
            }
            var bestShot: XCUIScreenshot?
            var bestBytes = 0
            for screen in screens {
                let shot = screen.screenshot()
                let bytes = shot.pngRepresentation.count
                if bytes > 5000, bytes >= bestBytes {
                    bestShot = shot
                    bestBytes = bytes
                }
            }
            if let bestShot { return bestShot }
        }
        return XCUIScreen.main.screenshot()
    }

    /// 像素级 idle 等待：连续截屏哈希相等即视为稳定（状态栏已钉静态时间，不产生假运动）；
    /// 超时不失败只告警（对齐 argent idle 语义）
    private func awaitIdle(body: [String: Any], step: Int) throws {
        let timeout = (body["timeoutMs"] as? Double ?? 10_000) / 1000
        let stable = (body["stableMs"] as? Double ?? 600) / 1000
        let required = max(2, Int((stable / 0.25).rounded()) + 1)
        var lastHash = -1
        var streak = 0
        let deadline = Date().addingTimeInterval(timeout)
        while Date() < deadline {
            let hash = activeScreenScreenshot().pngRepresentation.hashValue
            if hash == lastHash {
                streak += 1
            } else {
                streak = 1
                lastHash = hash
            }
            if streak >= required { return }
            Thread.sleep(forTimeInterval: 0.25)
        }
        print("[flow \(step)] await idle 超时（\(Int(timeout * 1000))ms），继续执行")
    }

    /// 黑屏防护：截屏哈希比对，画面全黑时等待（最长 5s）
    /// 原理：取 PNG 前几百字节的哈希（全黑 PNG 压缩后头部特征固定）
    private func awaitNonBlackScreen(step: Int, app: XCUIApplication? = nil) throws {
        let deadline = Date().addingTimeInterval(5)
        while Date() < deadline {
            let png = activeScreenScreenshot(app: app).pngRepresentation
            // 全黑判定：PNG 数据极小（< 5KB 的 1320×2868 全黑图）
            if png.count > 5000 { return }
            print("[flow \(step)] 检测到黑屏，等待画面就绪...")
            Thread.sleep(forTimeInterval: 0.5)
        }
        print("[flow \(step)] 黑屏等待超时（5s），继续截图")
    }

    // MARK: - 系统弹窗（保存密码 / AutoFill）自动消解与点击兜底

    private static let passwordDismissLabels: [String] = [
        "以后", "不保存", "稍后", "Not Now", "Never for This Website", "Never",
    ]

    /// 自动检测并关闭 iOS 系统“保存密码 / Save Password”半屏弹窗（iPhone 常见、iPad 不弹）
    private func dismissSystemPromptsIfNeeded(app: XCUIApplication) {
        let springboard = XCUIApplication(bundleIdentifier: "com.apple.springboard")
        for host in [app, springboard] {
            guard host.sheets.firstMatch.exists || host.alerts.firstMatch.exists else { continue }
            for label in Self.passwordDismissLabels {
                let sheetBtn = host.sheets.buttons[label].firstMatch
                if sheetBtn.exists {
                    smartTap(sheetBtn, app: host, step: 0)
                    Thread.sleep(forTimeInterval: 0.3)
                    return
                }
                let alertBtn = host.alerts.buttons[label].firstMatch
                if alertBtn.exists {
                    smartTap(alertBtn, app: host, step: 0)
                    Thread.sleep(forTimeInterval: 0.3)
                    return
                }
            }
        }
    }

    /// 智能点击：优先等 isHittable（1.0s）；若像 iPhone Duo 侧边快捷轨/悬浮层那样 exists=true 但 isHittable=false，
    /// 自动回退为元素 frame 中心点坐标点击，彻底消解 XCTest hit-test 假阴性。
    private func smartTap(_ element: XCUIElement, app: XCUIApplication, step: Int) {
        if element.isHittable {
            element.tap()
            return
        }
        let hitExpectation = expectation(for: NSPredicate(format: "isHittable == true"), evaluatedWith: element)
        let hitResult = XCTWaiter().wait(for: [hitExpectation], timeout: 1.0)
        if hitResult == .completed || element.isHittable {
            element.tap()
            return
        }
        let frame = element.frame
        if element.exists, !frame.isEmpty, frame.width > 0, frame.height > 0 {
            let midX = frame.midX
            let midY = frame.midY
            print("[flow \(step)] isHittable=false，自动改用元素中心坐标点击 (\(Int(midX)), \(Int(midY)))")
            let origin = app.coordinate(withNormalizedOffset: CGVector(dx: 0, dy: 0))
            origin.withOffset(CGVector(dx: midX, dy: midY)).tap()
            return
        }
        element.tap()
    }

    /// 稳健输入：在 iPhone Duo 等软键盘不弹出的环境下，若 element.typeText 缺乏软键盘焦点，自动通过坐标重聚焦并回退 app.typeText
    private func typeTextResiliently(_ text: String, into element: XCUIElement?, app: XCUIApplication, step: Int) {
        if let element, element.exists {
            let hasFocus = (element.value(forKey: "hasKeyboardFocus") as? Bool) ?? true
            if !hasFocus {
                let frame = element.frame
                if !frame.isEmpty, frame.width > 0, frame.height > 0 {
                    app.coordinate(withNormalizedOffset: .zero)
                        .withOffset(CGVector(dx: frame.midX, dy: frame.midY))
                        .tap()
                    Thread.sleep(forTimeInterval: 0.2)
                }
            }
            element.typeText(text)
        } else {
            app.typeText(text)
        }
    }

    private func isKeyboardSubmitLabel(_ body: [String: Any]) -> Bool {
        let target = ((body["text"] as? String) ?? (body["label"] as? String) ?? "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
        let submitKeywords: Set<String> = [
            "return", "done", "search", "go", "send", "next", "join",
            "完成", "搜索", "前往", "发送", "换行", "确认", "确定",
        ]
        return submitKeywords.contains(target)
    }

    // MARK: - 元素解析（按控件角色与精确度分级，消解全树 firstMatch 容器歧义）

    private func waitForResolvedElement(
        _ body: [String: Any],
        app: XCUIApplication,
        action: String,
        step: Int,
        timeout: TimeInterval
    ) throws -> XCUIElement? {
        // 先校验选择器合法性
        let hasID = !((body["id"] as? String) ?? "").isEmpty
        let hasText = !((body["text"] as? String) ?? "").isEmpty
        let hasLabel = !((body["label"] as? String) ?? "").isEmpty
        guard hasID || hasText || hasLabel else {
            throw runnerError(step, "\(action) 选择器需要 id / text / label / {x,y} 之一")
        }

        let deadline = Date().addingTimeInterval(timeout)
        var didCheckSystemPrompt = false

        while true {
            if let match = resolveImmediateElement(body, in: app, action: action) {
                return match
            }
            // 若点击的是系统弹窗按钮（如“以后/不保存/Not Now”），同步在 SpringBoard 进程中查找
            if isSystemSheetCandidate(body) {
                let springboard = XCUIApplication(bundleIdentifier: "com.apple.springboard")
                if let sbMatch = resolveImmediateElement(body, in: springboard, action: action) {
                    return sbMatch
                }
            }
            if Date() >= deadline {
                break
            }
            if !didCheckSystemPrompt {
                didCheckSystemPrompt = true
                dismissSystemPromptsIfNeeded(app: app)
            }
            Thread.sleep(forTimeInterval: 0.25)
        }
        return nil
    }

    private func isSystemSheetCandidate(_ body: [String: Any]) -> Bool {
        let raw = ((body["text"] as? String) ?? (body["label"] as? String) ?? "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        guard !raw.isEmpty else { return false }
        return Self.passwordDismissLabels.contains { $0.caseInsensitiveCompare(raw) == .orderedSame }
            || ["允许", "不允许", "Allow", "Don’t Allow", "Don't Allow", "好", "OK", "取消", "Cancel"].contains(raw)
    }

    private func resolveImmediateElement(
        _ body: [String: Any],
        in app: XCUIApplication,
        action: String
    ) -> XCUIElement? {
        let explicitRole = (body["role"] as? String)?.trimmingCharacters(in: .whitespacesAndNewlines)
        let explicitIndex = body["index"] as? Int
        let exactOnly = body["exact"] as? Bool == true

        let prioritizedQueries = candidateQueries(for: action, explicitRole: explicitRole, in: app)
        let appFrame = app.frame

        if let identifier = body["id"] as? String, !identifier.isEmpty {
            let idPred = NSPredicate(format: "identifier == %@", identifier)
            if let hit = pickBestElement(matching: idPred, in: prioritizedQueries, index: explicitIndex, appFrame: appFrame) {
                return hit
            }
            let fallback = app.descendants(matching: .any).matching(identifier: identifier)
            return pickFromQuery(fallback, index: explicitIndex, appFrame: appFrame)
        }

        let target = ((body["text"] as? String) ?? (body["label"] as? String) ?? "")
        guard !target.isEmpty else { return nil }

        // 第一优先级：在交互角色查询中做大小写不敏感的精确匹配（==[c]），避免“登录”误中“立即登录账号”或外层容器
        let exactPredicate = NSPredicate(
            format: "label ==[c] %@ OR placeholderValue ==[c] %@ OR value ==[c] %@",
            target, target, target
        )
        if let hit = pickBestElement(matching: exactPredicate, in: prioritizedQueries, index: explicitIndex, appFrame: appFrame) {
            return hit
        }

        // 第二优先级：若未要求 exact: true，在交互角色查询中做包含匹配（CONTAINS[c]）
        if !exactOnly {
            let containsPredicate = NSPredicate(
                format: "label CONTAINS[c] %@ OR placeholderValue CONTAINS[c] %@",
                target, target
            )
            if let hit = pickBestElement(matching: containsPredicate, in: prioritizedQueries, index: explicitIndex, appFrame: appFrame) {
                return hit
            }
        }

        // 第三优先级：兜底搜索 Other / 全树（排除占满全屏的根容器 Window/Other）
        if explicitRole == nil {
            let fallbackPredicate = exactOnly
                ? exactPredicate
                : NSPredicate(format: "label CONTAINS[c] %@ OR placeholderValue CONTAINS[c] %@", target, target)
            let otherQuery = app.otherElements.matching(fallbackPredicate)
            if let hit = pickFromQuery(otherQuery, index: explicitIndex, appFrame: appFrame, skipFullScreenContainer: true) {
                return hit
            }
        }
        return nil
    }

    private func candidateQueries(for action: String, explicitRole: String?, in app: XCUIApplication) -> [XCUIElementQuery] {
        if let role = explicitRole?.lowercased(), !role.isEmpty {
            switch role {
            case "button", "btn":
                return [
                    app.buttons,
                    app.segmentedControls.buttons,
                    app.navigationBars.buttons,
                    app.tabBars.buttons,
                    app.sheets.buttons,
                    app.alerts.buttons,
                ]
            case "textfield", "input":
                return [app.textFields, app.searchFields, app.secureTextFields, app.textViews]
            case "securetextfield", "password":
                return [app.secureTextFields, app.textFields]
            case "statictext", "text", "label":
                return [app.staticTexts]
            case "cell", "row":
                return [app.cells]
            case "switch", "toggle":
                return [app.switches, app.toggles]
            case "tab":
                return [app.tabBars.buttons, app.segmentedControls.buttons]
            default:
                return [app.descendants(matching: .any)]
            }
        }

        switch action {
        case "type":
            return [
                app.textFields,
                app.secureTextFields,
                app.searchFields,
                app.textViews,
            ]
        case "tap":
            return [
                app.sheets.buttons,
                app.alerts.buttons,
                app.buttons,
                app.segmentedControls.buttons,
                app.tabBars.buttons,
                app.navigationBars.buttons,
                app.cells,
                app.switches,
                app.toggles,
                app.links,
                app.textFields,
                app.secureTextFields,
                app.searchFields,
                app.staticTexts,
                app.images,
            ]
        default: // await
            return [
                app.staticTexts,
                app.buttons,
                app.navigationBars,
                app.textFields,
                app.secureTextFields,
                app.searchFields,
                app.cells,
                app.images,
            ]
        }
    }

    private func pickBestElement(
        matching predicate: NSPredicate,
        in queries: [XCUIElementQuery],
        index: Int?,
        appFrame: CGRect
    ) -> XCUIElement? {
        for query in queries {
            let matched = query.matching(predicate)
            if let hit = pickFromQuery(matched, index: index, appFrame: appFrame) {
                return hit
            }
        }
        return nil
    }

    private func pickFromQuery(
        _ matched: XCUIElementQuery,
        index: Int?,
        appFrame: CGRect,
        skipFullScreenContainer: Bool = false
    ) -> XCUIElement? {
        if let index, index >= 0 {
            let el = matched.element(boundBy: index)
            return el.exists ? el : nil
        }
        let first = matched.firstMatch
        guard first.exists else { return nil }

        let total = min(matched.count, 8)
        if total <= 1 {
            if skipFullScreenContainer, isFullScreenContainer(first.frame, appFrame: appFrame) {
                return nil
            }
            return first
        }

        var firstValidFrameElement: XCUIElement?
        for i in 0..<total {
            let candidate = matched.element(boundBy: i)
            guard candidate.exists else { continue }
            let frame = candidate.frame
            if skipFullScreenContainer, isFullScreenContainer(frame, appFrame: appFrame) {
                continue
            }
            if candidate.isHittable, frame.width > 1, frame.height > 1 {
                return candidate
            }
            if firstValidFrameElement == nil, frame.width > 1, frame.height > 1 {
                firstValidFrameElement = candidate
            }
        }
        return firstValidFrameElement ?? (skipFullScreenContainer ? nil : first)
    }

    private func isFullScreenContainer(_ frame: CGRect, appFrame: CGRect) -> Bool {
        guard appFrame.width > 0, appFrame.height > 0 else { return false }
        return frame.width >= appFrame.width * 0.96 && frame.height >= appFrame.height * 0.88
    }

    private func normalizedCoordinate(_ body: [String: Any]) -> (x: CGFloat, y: CGFloat)? {
        guard let x = body["x"] as? Double, let y = body["y"] as? Double,
              x >= 0, x <= 1, y >= 0, y <= 1 else { return nil }
        return (CGFloat(x), CGFloat(y))
    }

    // MARK: - 报错（附现场层级）

    private func notFound(_ body: [String: Any], step: Int, action: String, app: XCUIApplication) -> Error {
        let attachment = XCTAttachment(string: app.debugDescription)
        attachment.name = "failed-hierarchy-step\(step)"
        attachment.lifetime = .keepAlways
        add(attachment)
        let selector = body.compactMap { key, value -> String? in
            if let str = value as? String { return "\(key)=\(str)" }
            if let num = value as? NSNumber { return "\(key)=\(num)" }
            return nil
        }.sorted().joined(separator: " ")
        return runnerError(step, "\(action) 找不到元素（\(selector)），已附现场层级附件")
    }

    private func runnerError(_ step: Int, _ message: String) -> Error {
        NSError(domain: "FlowRunner", code: step,
                userInfo: [NSLocalizedDescriptionKey: step > 0 ? "[步骤 \(step)] \(message)" : message])
    }
}
