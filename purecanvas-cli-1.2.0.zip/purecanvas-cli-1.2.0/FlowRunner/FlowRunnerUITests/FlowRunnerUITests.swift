/*
input: 环境变量 PURECANVAS_FLOW_FILE（流程 JSON 路径）、PURECANVAS_MODE（replay|describe|session）、PURECANVAS_BUNDLE_ID（覆盖 flow.app）、PURECANVAS_SESSION_DIR（session 模式文件通道目录）。
output: replay 回放流程落截图附件；describe 落层级文本附件；session 长驻文件通道（cmd-*.json → resp-*.json，空闲 30 分钟自退），交互执行 tap/type/await/shot/describe。
pos: purecanvas capture 的执行体（独立子工程，由 CLI build-for-testing 后 test-without-building 驱动）；流程校验在 CLI 侧 FlowSpec 完成，runner 只做宽松解析；一旦我被更新，务必更新我的开头注释。
*/
import XCTest

final class FlowRunnerUITests: XCTestCase {
    private enum Mode: String { case replay, describe, session }

    private struct Flow {
        var bundleID: String
        var steps: [[String: Any]]
    }

    private var flow: Flow?

    override func setUpWithError() throws {
        continueAfterFailure = false
        let mode = Mode(rawValue: ProcessInfo.processInfo.environment["PURECANVAS_MODE"] ?? "replay") ?? .replay
        if mode == .session {
            // 会话模式无流程文件：bundle id 由 launch 命令提供
            flow = nil
            return
        }
        let env = ProcessInfo.processInfo.environment
        let flowPath = env["PURECANVAS_FLOW_FILE"] ?? ""

        guard !flowPath.isEmpty else {
            throw runnerError(0, "缺少 PURECANVAS_FLOW_FILE（CLI 应以 TEST_RUNNER_ 前缀透传并先经 FlowSpec 校验）")
        }
        guard let data = FileManager.default.contents(atPath: flowPath),
              let root = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            throw runnerError(0, "流程文件不可读或非 JSON 对象：\(flowPath)")
        }
        let bundleID = env["PURECANVAS_BUNDLE_ID"] ?? (root["app"] as? String ?? "")
        guard !bundleID.isEmpty else {
            throw runnerError(0, "流程缺少 app（bundle id），也未提供 PURECANVAS_BUNDLE_ID 覆盖")
        }
        let steps = root["steps"] as? [[String: Any]] ?? []
        flow = Flow(bundleID: bundleID, steps: steps)
    }

    func testFlow() throws {
        let mode = Mode(rawValue: ProcessInfo.processInfo.environment["PURECANVAS_MODE"] ?? "replay") ?? .replay

        switch mode {
        case .session:
            try runSession()
        case .describe:
            guard let flow else { return }
            try runDescribe(XCUIApplication(bundleIdentifier: flow.bundleID))
        case .replay:
            guard let flow else { return }
            try runReplay(XCUIApplication(bundleIdentifier: flow.bundleID), flow)
        }
    }

    // MARK: - session 模式：文件通道长驻（cmd-*.json → resp-*.json）

    private struct SessionCommand {
        let id: String
        let action: String
        let params: [String: Any]
        let fileURL: URL
    }

    /// 空闲自退：无命令超过该时长写 end 退出（避免长期占后台）
    private static let sessionIdleTimeout: TimeInterval = 30 * 60
    private static let sessionPollInterval: TimeInterval = 0.15

    private func runSession() throws {
        // 会话默认 executionTimeAllowance 10 分钟（启用 test timeouts 时）会杀进程——显式放宽
        executionTimeAllowance = 28 * 3600
        let env = ProcessInfo.processInfo.environment
        let channelPath = env["PURECANVAS_SESSION_DIR"] ?? ""
        guard !channelPath.isEmpty else {
            throw runnerError(0, "session 模式缺少 PURECANVAS_SESSION_DIR（宿主文件通道目录）")
        }
        let channel = URL(fileURLWithPath: channelPath, isDirectory: true)
        try FileManager.default.createDirectory(at: channel, withIntermediateDirectories: true)
        try Data("ready \(Date().timeIntervalSince1970)".utf8).write(to: channel.appendingPathComponent("ready"))

        var application: XCUIApplication?
        var lastActivity = Date()

        while true {
            let commands = pollSessionCommands(channel: channel)
            for command in commands {
                lastActivity = Date()
                let reply = executeSessionCommand(command, application: &application)
                try? JSONSerialization.data(withJSONObject: reply)
                    .write(to: channel.appendingPathComponent("resp-\(command.id).json"))
                try? FileManager.default.removeItem(at: command.fileURL)
                if command.action == "stop" {
                    try? Data("stop \(Date().timeIntervalSince1970)".utf8)
                        .write(to: channel.appendingPathComponent("end"))
                    return
                }
            }
            if Date().timeIntervalSince(lastActivity) > Self.sessionIdleTimeout {
                try? Data("idle \(Date().timeIntervalSince1970)".utf8)
                    .write(to: channel.appendingPathComponent("end"))
                return
            }
            Thread.sleep(forTimeInterval: Self.sessionPollInterval)
        }
    }

    private func pollSessionCommands(channel: URL) -> [SessionCommand] {
        let files = (try? FileManager.default.contentsOfDirectory(at: channel, includingPropertiesForKeys: nil)) ?? []
        return files
            .filter { $0.lastPathComponent.hasPrefix("cmd-") && $0.pathExtension == "json" }
            .sorted { $0.lastPathComponent < $1.lastPathComponent }
            .compactMap { url in
                guard let data = FileManager.default.contents(atPath: url.path),
                      let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                      let id = obj["id"] as? String,
                      let action = obj["action"] as? String else { return nil }
                return SessionCommand(id: id, action: action, params: obj["params"] as? [String: Any] ?? [:], fileURL: url)
            }
    }

    /// 会话命令执行：tap/type/await/wait/swipe/terminate 复用 executeStep；launch/describe/shot/ping/stop 会话专属
    private func executeSessionCommand(_ command: SessionCommand, application: inout XCUIApplication?) -> [String: Any] {
        func reply(_ ok: Bool, _ data: [String: Any], _ error: String?) -> [String: Any] {
            var payload: [String: Any] = ["id": command.id, "ok": ok]
            data.forEach { payload[$0.key] = $0.value }
            if let error { payload["error"] = error }
            return payload
        }

        switch command.action {
        case "ping":
            return reply(true, ["uptime": Date().timeIntervalSince1970], nil)

        case "launch":
            let bundleID = command.params["bundleId"] as? String ?? ""
            guard !bundleID.isEmpty else { return reply(false, [:], "launch 需要 bundleId") }
            let app = application ?? XCUIApplication(bundleIdentifier: bundleID)
            application = app
            // 附着语义：已在前台且未要求重启则直接复用（describe 循环不重付启动成本）
            if app.state == .runningForeground, command.params["relaunch"] as? Bool != true {
                return reply(true, ["bundleId": bundleID, "attached": true], nil)
            }
            do {
                try executeStep(["launch": [:]], index: 0, app: app)
                return reply(true, ["bundleId": bundleID, "attached": false], nil)
            } catch {
                return reply(false, [:], error.localizedDescription)
            }

        case "describe":
            guard let app = application, app.state == .runningForeground else {
                return reply(false, [:], "App 未运行——先执行 launch")
            }
            return reply(true, ["hierarchy": app.debugDescription], nil)

        case "shot":
            guard application != nil else { return reply(false, [:], "App 未运行——先执行 launch") }
            let png = XCUIScreen.main.screenshot().pngRepresentation
            return reply(true, ["pngBase64": png.base64EncodedString()], nil)

        case "tap", "type", "await", "wait", "swipe", "terminate":
            guard let app = application, app.state == .runningForeground else {
                return reply(false, [:], "App 未运行——先执行 launch")
            }
            do {
                try executeStep([command.action: command.params], index: 0, app: app)
                return reply(true, [:], nil)
            } catch {
                return reply(false, [:], error.localizedDescription)
            }

        case "stop":
            return reply(true, [:], nil)

        default:
            return reply(false, [:], "未知会话命令 '\(command.action)'")
        }
    }

    // MARK: - describe 模式：UI 层级文本（identifier/label/frame），AI 据此写流程选择器

    private func runDescribe(_ application: XCUIApplication) throws {
        if application.state != .runningForeground {
            application.launch()
        }
        Thread.sleep(forTimeInterval: 1.0)
        let attachment = XCTAttachment(string: application.debugDescription)
        attachment.name = "describe-hierarchy"
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    // MARK: - replay 模式

    private func runReplay(_ application: XCUIApplication, _ flow: Flow) throws {
        guard !flow.steps.isEmpty else {
            throw runnerError(0, "流程 steps 为空")
        }
        for (index, rawStep) in flow.steps.enumerated() {
            try executeStep(rawStep, index: index, app: application)
        }
    }

    private func executeStep(_ rawStep: [String: Any], index: Int, app: XCUIApplication) throws {
        let step = index + 1
        guard let action = rawStep.keys.first else { return }
        switch action {
        case "echo":
            print("[flow \(step)] \(rawStep[action] ?? "")")

        case "launch":
            // launch 偶发与 springboard 竞态：状态没起来就 terminate 重拉一次（对齐 goldie 经验）
            app.launch()
            Thread.sleep(forTimeInterval: 1.0)
            if app.state != .runningForeground {
                app.terminate()
                Thread.sleep(forTimeInterval: 1.5)
                app.launch()
                Thread.sleep(forTimeInterval: 1.0)
            }

        case "tap":
            guard let body = rawStep[action] as? [String: Any] else { throw runnerError(step, "tap 缺少参数对象") }
            if let coord = normalizedCoordinate(body) {
                app.coordinate(withNormalizedOffset: CGVector(dx: coord.x, dy: coord.y)).tap()
            } else {
                let element = try resolveElement(body, app: app, action: "tap", step: step)
                // 存在 ≠ 可点：页面动画/遮挡中合成点击会落空——先等 isHittable（经 8s 预算）
                let hitExpectation = expectation(for: NSPredicate(format: "isHittable == true"), evaluatedWith: element)
                let hitResult = XCTWaiter().wait(for: [hitExpectation], timeout: 8)
                guard element.exists, hitResult == .completed || element.isHittable else {
                    throw notFound(body, step: step, action: "tap", app: app)
                }
                element.tap()
            }

        case "type":
            guard let body = rawStep[action] as? [String: Any],
                  let text = body["text"] as? String else {
                throw runnerError(step, "type 需要 {into: <选择器>, text: <文本>, submit: Bool?}")
            }
            let into = body["into"] as? [String: Any] ?? [:]
            let element = try resolveElement(into, app: app, action: "type", step: step)
            guard element.waitForExistence(timeout: 8) else {
                throw notFound(into, step: step, action: "type", app: app)
            }
            element.tap()
            Thread.sleep(forTimeInterval: 0.2)
            element.typeText(text)
            if body["submit"] as? Bool == true {
                element.typeText("\n")
            }

        case "await":
            guard let body = rawStep[action] as? [String: Any] else {
                throw runnerError(step, "await 需要 {visible: <选择器>} 或 {idle: true}")
            }
            if body["idle"] as? Bool == true {
                try awaitIdle(body: body, step: step)
                return
            }
            guard let condition = body["visible"] as? [String: Any] else {
                throw runnerError(step, "await 支持 {visible: <选择器>, timeoutMs: Int?} 或 {idle: true, stableMs: Int?}")
            }
            let timeout = (body["timeoutMs"] as? Double ?? 8000) / 1000
            let element = try resolveElement(condition, app: app, action: "await", step: step)
            let hit = timeout > 0 ? element.waitForExistence(timeout: timeout) : element.exists
            guard hit else {
                throw notFound(condition, step: step, action: "await", app: app)
            }

        case "record":
            // 录屏由 CLI 在会话模式下经 simctl recordVideo 驱动；一次性回放无法逐段控制
            throw runnerError(step, "record 步骤需要会话模式（CLI 检测到 record 会自动切换；若手动跑 xcodebuild 请去掉 record 步骤）")

        case "wait":
            let ms = rawStep[action] as? Double ?? 0
            Thread.sleep(forTimeInterval: max(0, ms) / 1000)

        case "swipe":
            guard let body = rawStep[action] as? [String: Any],
                  let direction = body["direction"] as? String else {
                throw runnerError(step, "swipe 需要 {direction: up|down|left|right}")
            }
            switch direction {
            case "up": app.swipeUp()
            case "down": app.swipeDown()
            case "left": app.swipeLeft()
            case "right": app.swipeRight()
            default: throw runnerError(step, "未知 swipe 方向 '\(direction)'")
            }

        case "shot":
            guard let body = rawStep[action] as? [String: Any],
                  let name = body["name"] as? String, !name.isEmpty else {
                throw runnerError(step, "shot 需要 {name: <文件名，不含扩展>}")
            }
            // 黑屏防护：截图前确认画面非全黑（撞启动动画时自动等待）
            try awaitNonBlackScreen(step: step)
            let attachment = XCTAttachment(screenshot: XCUIScreen.main.screenshot())
            attachment.name = name
            attachment.lifetime = .keepAlways
            add(attachment)

        case "terminate":
            app.terminate()

        default:
            throw runnerError(step, "未知 action '\(action)'（FlowSpec 校验应已在 CLI 侧拦截）")
        }
    }

    /// 像素级 idle 等待：连续截屏哈希相等即视为稳定（状态栏已钉静态时间，不产生假运动）；
    /// 超时不失败只告警（对齐 argent idle 语义）
    private func awaitIdle(body: [String: Any], step: Int) throws {
        let timeout = (body["timeoutMs"] as? Double ?? 10_000) / 1000
        let stable = (body["stableMs"] as? Double ?? 600) / 1000
        let required = max(2, Int((stable / 0.25).rounded()) + 1)
        var lastHash = -1
        var streak = 0
        let deadline = Date().addingTimeInterval(timeout)
        while Date() < deadline {
            let hash = XCUIScreen.main.screenshot().pngRepresentation.hashValue
            if hash == lastHash {
                streak += 1
            } else {
                streak = 1
                lastHash = hash
            }
            if streak >= required { return }
            Thread.sleep(forTimeInterval: 0.25)
        }
        print("[flow \(step)] await idle 超时（\(Int(timeout * 1000))ms），继续执行")
    }

    /// 黑屏防护：截屏哈希比对，画面全黑时等待（最长 5s）
    /// 原理：取 PNG 前几百字节的哈希（全黑 PNG 压缩后头部特征固定）
    private func awaitNonBlackScreen(step: Int) throws {
        let deadline = Date().addingTimeInterval(5)
        while Date() < deadline {
            let png = XCUIScreen.main.screenshot().pngRepresentation
            // 全黑判定：PNG 数据极小（< 5KB 的 1320×2868 全黑图）
            if png.count > 5000 { return }
            print("[flow \(step)] 检测到黑屏，等待画面就绪...")
            Thread.sleep(forTimeInterval: 0.5)
        }
        print("[flow \(step)] 黑屏等待超时（5s），继续截图")
    }

    // MARK: - 元素解析

    private func resolveElement(_ body: [String: Any], app: XCUIApplication, action: String, step: Int) throws -> XCUIElement {
        if let identifier = body["id"] as? String, !identifier.isEmpty {
            return app.descendants(matching: .any).matching(identifier: identifier).firstMatch
        }
        // text/label 同时匹配 label 与 placeholderValue（表单输入框常只有 placeholder）
        // exact: true 时用 == 精确匹配（避免 CONTAINS 误中同名子串）
        let exact = body["exact"] as? Bool == true
        if let text = body["text"] as? String, !text.isEmpty {
            let format = exact
                ? "label == %@ OR placeholderValue == %@"
                : "label CONTAINS[c] %@ OR placeholderValue CONTAINS[c] %@"
            return app.descendants(matching: .any)
                .element(matching: NSPredicate(format: format, text, text))
                .firstMatch
        }
        if let label = body["label"] as? String, !label.isEmpty {
            let format = exact
                ? "label == %@ OR placeholderValue == %@"
                : "label CONTAINS[c] %@ OR placeholderValue CONTAINS[c] %@"
            return app.descendants(matching: .any)
                .element(matching: NSPredicate(format: format, label, label))
                .firstMatch
        }
        throw runnerError(step, "\(action) 选择器需要 id / text / label / {x,y} 之一")
    }

    private func normalizedCoordinate(_ body: [String: Any]) -> (x: CGFloat, y: CGFloat)? {
        guard let x = body["x"] as? Double, let y = body["y"] as? Double,
              x >= 0, x <= 1, y >= 0, y <= 1 else { return nil }
        return (CGFloat(x), CGFloat(y))
    }

    // MARK: - 报错（附现场层级）

    private func notFound(_ body: [String: Any], step: Int, action: String, app: XCUIApplication) -> Error {
        let attachment = XCTAttachment(string: app.debugDescription)
        attachment.name = "failed-hierarchy-step\(step)"
        attachment.lifetime = .keepAlways
        add(attachment)
        let selector = body.compactMap { key, value -> String? in
            guard let value = value as? String else { return nil }
            return "\(key)=\(value)"
        }.joined(separator: " ")
        return runnerError(step, "\(action) 找不到元素（\(selector)），已附现场层级附件")
    }

    private func runnerError(_ step: Int, _ message: String) -> Error {
        NSError(domain: "FlowRunner", code: step,
                userInfo: [NSLocalizedDescriptionKey: step > 0 ? "[步骤 \(step)] \(message)" : message])
    }
}
