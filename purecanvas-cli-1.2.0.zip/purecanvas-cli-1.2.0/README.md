# purecanvas CLI

PureCanvas 的命令行工具：采集（模拟器截图/录屏/流程驱动 UI 导航）→ 套壳 →
多语言成图 → 商店规格校验 → 预览视频。

## 要求

- macOS 14+
- Xcode（含命令行工具；流程采集需要完整 Xcode，`xcodebuild -version` 可查）

## 快速开始

    ./purecanvas --version
    ./purecanvas help
    ./purecanvas capture doctor          # 环境体检（模拟器/Xcode/工作区）
    ./purecanvas capture describe --bundle-id com.example.app   # 看 App 实时 UI 层级

## 常驻桥（供 PureCanvas 商店版 / MCP 调采集）

    ./purecanvas serve                  # 前台运行；Ctrl-C 退出
    # 状态文件：~/Library/Group Containers/group.com.lcc.shotcomposer/PureCanvas/Runners/bridge.json

## 首次运行

本包由 release-cli.sh 组装：Developer ID 签名 + Apple 公证（已执行则 Gatekeeper 直接放行）。
若拿到的是未签名快照（开发构建），可 `xattr -c <解压目录>` 后运行。
